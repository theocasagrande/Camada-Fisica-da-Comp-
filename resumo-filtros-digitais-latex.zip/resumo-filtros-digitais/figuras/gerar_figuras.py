"""Gera as figuras do resumo de Filtros Digitais (Projeto 7 - Camada Física).

Todas as figuras usam o mesmo filtro do curso: Butterworth passa-baixa,
2a ordem, corte de 500 Hz, fs = 44 100 Hz. Rode com:  python3 gerar_figuras.py
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter
from matplotlib.patches import FancyBboxPatch
from scipy.signal import butter, freqz, lfilter, iirpeak, iirnotch

# ---------------------------------------------------------------- estilo
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Latin Modern Roman", "DejaVu Serif"],
    "mathtext.fontset": "cm",
    "font.size": 9.5,
    "axes.titlesize": 10,
    "axes.labelsize": 9.5,
    "legend.fontsize": 8.5,
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.color": "#d9d9d9",
    "grid.linewidth": 0.6,
    "axes.edgecolor": "#444444",
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03,
})
AZUL = "#1f5fbf"
LARANJA = "#d9541e"
VERDE = "#2e8b57"
CINZA = "#6b6b6b"
ROXO = "#7a3fb0"
W = 6.3  # largura em polegadas (largura do texto no A4)

FS = 44100
B, A = butter(2, 500, btype="low", fs=FS)


def virgula(fmt="{:g}"):
    """Formatador que troca ponto decimal por vírgula."""
    return FuncFormatter(lambda v, _: fmt.format(v).replace(".", ","))


def ganho_db(b, a, f):
    _, h = freqz(b, a, worN=np.atleast_1d(f), fs=FS)
    return 20 * np.log10(np.maximum(np.abs(h), 1e-12))


def eixo_hz(ax, fmin=20, fmax=20000):
    ax.set_xscale("log")
    ax.set_xlim(fmin, fmax)
    ax.xaxis.set_major_formatter(FuncFormatter(
        lambda v, _: f"{v/1000:g} k".replace(".", ",") if v >= 1000 else f"{v:g}"))
    ax.grid(True, which="minor", color="#eeeeee", linewidth=0.4)


# ================================================================ 1. tipos
def fig_tipos():
    f = np.logspace(np.log10(20), np.log10(20000), 3000)
    filtros = []
    filtros.append(("Passa-baixa", butter(2, 500, "low", fs=FS), [500]))
    filtros.append(("Passa-alta", butter(2, 500, "high", fs=FS), [500]))
    filtros.append(("Passa-faixa", iirpeak(2000, 4, fs=FS), [2000]))
    filtros.append(("Rejeita-faixa (notch)", iirnotch(2000, 4, fs=FS), [2000]))

    # filtro de picos (equalizador, receita RBJ)
    def peak(f0, gdb, Q):
        Aa = 10 ** (gdb / 40)
        w0 = 2 * np.pi * f0 / FS
        al = np.sin(w0) / (2 * Q)
        b = np.array([1 + al * Aa, -2 * np.cos(w0), 1 - al * Aa])
        a = np.array([1 + al / Aa, -2 * np.cos(w0), 1 - al / Aa])
        return b / a[0], a / a[0]

    fig, axs = plt.subplots(2, 3, figsize=(W, 3.6), sharey=False)
    axs = axs.ravel()
    for ax, (nome, (b, a), marcas) in zip(axs, filtros):
        g = ganho_db(b, a, f)
        ax.plot(f, g, color=AZUL, lw=1.6)
        for m in marcas:
            ax.axvline(m, color=LARANJA, lw=0.9, ls="--")
        ax.set_title(nome)
        ax.set_ylim(-45, 6)
        eixo_hz(ax)
    ax = axs[4]
    for gdb, cor, rot in [(9, VERDE, "+9 dB"), (-9, LARANJA, "−9 dB")]:
        b, a = peak(2000, gdb, 1.5)
        ax.plot(f, ganho_db(b, a, f), color=cor, lw=1.6, label=rot)
    ax.axvline(2000, color=CINZA, lw=0.9, ls="--")
    ax.set_title("Picos (peak / equalizador)")
    ax.set_ylim(-15, 15)
    ax.legend(loc="lower left", frameon=False)
    eixo_hz(ax)
    for ax in axs[:5]:
        ax.set_xlabel("frequência (Hz)")
    for ax in (axs[0], axs[3]):
        ax.set_ylabel("ganho (dB)")
    axs[5].axis("off")
    axs[5].text(0.02, 0.5,
                "Linha tracejada:\nfrequência de corte\nou frequência central.\n\n"
                "0 dB = passa intacto\nmuito negativo = cortado",
                va="center", fontsize=9, color="#333333")
    fig.tight_layout(w_pad=1.0, h_pad=1.4)
    fig.savefig("fig_tipos.pdf")
    plt.close(fig)


# ================================================================ 2. senoides
def fig_senoides():
    casos = [159.2, 656.8, 1591.5]
    T = 0.02
    t = np.arange(0, T, 1 / FS)
    fig = plt.figure(figsize=(W, 3.9))
    for i, f0 in enumerate(casos):
        _, h = freqz(B, A, worN=[f0], fs=FS)
        g = abs(h[0])
        ph = np.angle(h[0])
        x = np.sin(2 * np.pi * f0 * t)
        y = g * np.sin(2 * np.pi * f0 * t + ph)
        y0 = 0.68 - i * 0.31
        ax_in = fig.add_axes([0.04, y0, 0.36, 0.24])
        ax_out = fig.add_axes([0.655, y0, 0.335, 0.24])
        for ax, sig, cor in [(ax_in, x, AZUL), (ax_out, y, LARANJA)]:
            ax.plot(t * 1000, sig, color=cor, lw=1.0)
            ax.set_ylim(-1.2, 1.2)
            ax.set_xlim(0, T * 1000)
            ax.set_yticks([-1, 0, 1])
            ax.grid(False)
            ax.spines["left"].set_color("#aaaaaa")
            ax.spines["bottom"].set_color("#aaaaaa")
            if i < 2:
                ax.set_xticklabels([])
        gdb = 20 * np.log10(g)
        ax_in.text(0.0, 1.07, f"entrada: $f\\approx{f0:.0f}$ Hz, amplitude 1".replace(".", ","),
                   transform=ax_in.transAxes, fontsize=8.5)
        ax_out.text(0.0, 1.07, f"saída: mesma $f$, amplitude ${g:.2f}$".replace(".", ","),
                    transform=ax_out.transAxes, fontsize=8.5)
        caixa = FancyBboxPatch((0.435, y0 + 0.035), 0.15, 0.17,
                               boxstyle="round,pad=0.01,rounding_size=0.02",
                               transform=fig.transFigure, fc="#e8eefb", ec=AZUL, lw=1)
        fig.patches.append(caixa)
        fig.text(0.51, y0 + 0.145, "$G(Z)$", ha="center", va="center", fontsize=11)
        rot = r"$\approx 0$ dB" if abs(gdb) < 0.05 else f"${gdb:.1f}$ dB".replace(".", "{,}")
        fig.text(0.51, y0 + 0.075, rot, ha="center", va="center", fontsize=8.5, color=AZUL)
        fig.add_artist(matplotlib.patches.FancyArrowPatch(
            (0.405, y0 + 0.12), (0.432, y0 + 0.12), transform=fig.transFigure,
            arrowstyle="-|>", mutation_scale=9, color=CINZA))
        fig.add_artist(matplotlib.patches.FancyArrowPatch(
            (0.588, y0 + 0.12), (0.618, y0 + 0.12), transform=fig.transFigure,
            arrowstyle="-|>", mutation_scale=9, color=CINZA))
    fig.text(0.22, -0.035, "tempo (ms)", ha="center", fontsize=9)
    fig.text(0.82, -0.035, "tempo (ms)", ha="center", fontsize=9)
    fig.savefig("fig_senoides.pdf")
    plt.close(fig)


# ================================================================ 3. média móvel
def fig_media_movel():
    w = np.linspace(0, np.pi, 600)
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.4))
    ax = axs[0]
    ax.plot(w, np.abs(np.cos(w / 2)), color=AZUL, lw=1.8,
            label=r"média: $y[k]=\frac{1}{2}(x[k]+x[k-1])$  →  razão $|\cos(\theta/2)|$  (passa-baixa)")
    ax.plot(w, np.abs(np.sin(w / 2)), color=LARANJA, lw=1.8,
            label=r"diferença: $y[k]=\frac{1}{2}(x[k]-x[k-1])$  →  razão $|\sin(\theta/2)|$  (passa-alta)")
    pts = [(0, 1), (np.pi / 2, np.cos(np.pi / 4)), (2 * np.pi / 3, 0.5), (np.pi, 0)]
    for wp, v in pts:
        ax.plot(wp, v, "o", color=AZUL, ms=4)
    ax.set_xticks([0, np.pi / 2, 2 * np.pi / 3, np.pi])
    ax.set_xticklabels(["0", r"$\pi/2$", r"$2\pi/3$", r"$\pi$"])
    ax.set_xlabel(r"$\theta$ (rad/amostra)")
    ax.set_ylabel(r"$V_{saída}/V_{entrada}$")
    ax.yaxis.set_major_formatter(virgula())
    ax.set_title("Razão de amplitudes (linear)")
    h, l = ax.get_legend_handles_labels()
    fig.legend(h, l, frameon=False, loc="lower center", ncol=1, fontsize=8,
               bbox_to_anchor=(0.5, -0.13))
    ax.set_ylim(-0.02, 1.08)

    ax = axs[1]
    ww = w[1:-1]
    ax.plot(ww, 20 * np.log10(np.cos(ww / 2)), color=AZUL, lw=1.8)
    ax.plot(ww, 20 * np.log10(np.sin(ww / 2)), color=LARANJA, lw=1.8)
    for lvl in (-3, -6):
        ax.axhline(lvl, color=CINZA, lw=0.8, ls=":")
        ax.text(0.05, lvl + 0.6, f"{lvl} dB".replace("-", "−"), fontsize=7.5, color=CINZA)
    ax.set_ylim(-30, 2)
    ax.set_xticks([0, np.pi / 2, 2 * np.pi / 3, np.pi])
    ax.set_xticklabels(["0", r"$\pi/2$", r"$2\pi/3$", r"$\pi$"])
    ax.set_xlabel(r"$\theta$ (rad/amostra)")
    ax.set_ylabel("ganho (dB)")
    ax.set_title("O mesmo, em decibéis")
    fig.tight_layout(w_pad=1.5)
    fig.savefig("fig_media_movel.pdf")
    plt.close(fig)


# ================================================================ 4. Bode
def fig_bode():
    wr = np.logspace(np.log10(5e2), np.log10(1.3e5), 4000)
    g = ganho_db(B, A, wr / (2 * np.pi))
    fig, ax = plt.subplots(figsize=(W, 3.5))
    ax.plot(wr, g, color=AZUL, lw=1.8)
    ax.set_xscale("log")
    ax.set_xlim(5e2, 1.3e5)
    ax.set_ylim(-90, 8)
    ax.set_xlabel(r"frequência angular $\omega$ (rad/s)")
    ax.set_ylabel("magnitude (dB)")
    ax.grid(True, which="minor", color="#eeeeee", linewidth=0.4)
    ax.xaxis.set_major_locator(LogLocator(base=10))

    g1 = ganho_db(B, A, 1e3 / (2 * np.pi))[0]
    g2 = ganho_db(B, A, 1e4 / (2 * np.pi))[0]
    w3 = 2 * np.pi * 499.4
    w6 = 2 * np.pi * 656.8
    ax.plot([5e2, w6], [-6, -6], color=ROXO, lw=0.8, ls=":")
    ax.plot([w6, w6], [-90, -6], color=ROXO, lw=0.8, ls=":")
    pts = [
        (1e3, g1, VERDE, r"$\omega=10^3$ rad/s ($\approx 159$ Hz): $\approx 0$ dB $\Rightarrow$ saída $\approx 50$  (4a, item a2)"),
        (w3, -3, CINZA, r"$-3$ dB em $\approx 3{,}1\times10^3$ rad/s ($\approx 500$ Hz): corte de projeto do Butterworth"),
        (w6, -6, ROXO, r"$-6$ dB em $\omega_c\approx 4{,}1\times10^3$ rad/s $\Rightarrow f_c=\omega_c/2\pi\approx 657$ Hz  (4b, convenção do curso)"),
        (1e4, g2, LARANJA, r"$\omega=10^4$ rad/s ($\approx 1592$ Hz): $\approx -20$ dB $\Rightarrow$ saída $\approx 5$  (4a, item a1)"),
    ]
    for w, gv, cor, rot in pts:
        ax.plot(w, gv, "o", color=cor, ms=6, zorder=5, label=rot)
    ax.legend(loc="lower left", frameon=True, framealpha=0.95, edgecolor="#dddddd",
              fontsize=7.8, handletextpad=0.3, borderpad=0.5)
    # eixo superior em Hz
    sec = ax.secondary_xaxis("top", functions=(lambda w: w / (2 * np.pi), lambda f: f * 2 * np.pi))
    sec.set_xlabel("frequência $f$ (Hz)", fontsize=8.5)
    sec.xaxis.set_major_formatter(FuncFormatter(
        lambda v, _: f"{v/1000:g} k".replace(".", ",") if v >= 1000 else f"{v:g}"))
    sec.xaxis.set_minor_formatter(NullFormatter())
    fig.tight_layout()
    fig.savefig("fig_bode.pdf")
    plt.close(fig)


# ================================================================ 5. polos
def fig_polos():
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.9), gridspec_kw={"width_ratios": [1, 1.25]})
    ax = axs[0]
    th = np.linspace(0, 2 * np.pi, 400)
    ax.plot(np.cos(th), np.sin(th), color=CINZA, lw=1)
    ax.fill(np.cos(th), np.sin(th), color="#eef4ee")
    pb = np.roots(A)
    pu = np.roots([1, -1.8, 0.7])
    ax.plot(pb.real, pb.imag, "x", color=AZUL, ms=8, mew=2, label="polos Butterworth")
    ax.plot([-1], [0], "o", mfc="none", mec=AZUL, ms=8, mew=1.6, label="zeros Butterworth (duplo)")
    ax.plot(pu.real, pu.imag, "x", color=LARANJA, ms=8, mew=2, label="polos do 1º exemplo")
    ax.set_aspect("equal")
    ax.set_xlim(-1.45, 1.45)
    ax.set_ylim(-1.3, 1.3)
    ax.axhline(0, color="#bbbbbb", lw=0.6)
    ax.axvline(0, color="#bbbbbb", lw=0.6)
    ax.set_xlabel("parte real")
    ax.set_ylabel("parte imaginária")
    ax.set_title("Polos e zeros no plano $Z$")
    ax.text(0, 0.45, "estável\n$|p|<1$", ha="center", fontsize=8, color=VERDE)
    ax.annotate("1,23\n(fora!)", xy=(1.2317, 0), xytext=(1.05, -0.75), fontsize=7.8,
                color=LARANJA, arrowprops=dict(arrowstyle="-", color=LARANJA, lw=0.7))
    h, l = ax.get_legend_handles_labels()
    fig.legend(h, l, frameon=False, fontsize=8, loc="lower center", ncol=3,
               bbox_to_anchor=(0.5, -0.06))
    ax.xaxis.set_major_formatter(virgula())
    ax.yaxis.set_major_formatter(virgula())

    ax = axs[1]
    n = np.arange(60)
    x = np.ones_like(n, dtype=float)
    yb = lfilter(B, A, x)
    yu = lfilter([0.2, 0.3, 0.2], [1, -1.8, 0.7], x)
    ax.semilogy(n, np.abs(yu) + 1e-6, color=LARANJA, lw=1.6, label="1º exemplo (instável)")
    ax.semilogy(n, np.abs(yb) + 1e-6, color=AZUL, lw=1.6, label="Butterworth (estável)")
    ax.set_xlabel("amostra $k$")
    ax.set_ylabel(r"$|y[k]|$ (escala log)")
    ax.set_title("Resposta a uma entrada constante $x[k]=1$")
    ax.legend(frameon=False, loc="upper left")
    fig.tight_layout(w_pad=1.2)
    fig.savefig("fig_polos.pdf")
    plt.close(fig)


# ================================================================ 6. decibéis
def fig_db():
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.7), gridspec_kw={"width_ratios": [1.05, 1]})
    ax = axs[0]
    I = np.logspace(-12, 2, 200)
    ax.plot(I, 10 * np.log10(I / 1e-12), color=AZUL, lw=1.8)
    ax.set_xscale("log")
    pts = [(1e-12, "limiar da audição: 0 dB", (8, 2)),
           (1e-6, r"conversa: $\approx 60$ dB", (8, -6)),
           (1e-4, "trânsito / música alta: 80 dB", (8, -6)),
           (1, "limiar da dor: 120 dB", (8, -9)),
           (1e2, r"100 W/m$^2$: 140 dB", (-88, -2))]
    for Iv, rot, off in pts:
        d = 10 * np.log10(Iv / 1e-12)
        ax.plot(Iv, d, "o", color=LARANJA if Iv in (1e-12, 1) else AZUL, ms=4.5)
        ax.annotate(rot, xy=(Iv, d), xytext=off, textcoords="offset points", fontsize=7.6)
    ax.set_xlabel(r"intensidade $I$ (W/m$^2$)")
    ax.set_ylabel(r"$I_{dB}$")
    ax.set_title(r"$I_{dB}=10\log_{10}(I/10^{-12})$")
    ax.set_xlim(3e-14, 3e4)
    ax.set_ylim(-8, 152)
    ax.set_xticks([1e-12, 1e-9, 1e-6, 1e-3, 1, 1e2])

    ax = axs[1]
    r = np.logspace(-3, 1, 400)
    ax.plot(r, 20 * np.log10(r), color=AZUL, lw=1.8)
    ax.set_xscale("log")
    alvos = [(0.01, "0,01 → −40 dB", (0.03, -45)), (0.1, "0,1 → −20 dB", (0.25, -26)),
             (0.5, "0,5 → −6 dB", (0.9, -16)), (0.707, "0,707 → −3 dB", (0.0016, -2)),
             (1, "1 → 0 dB", (0.0016, 9)), (2, "2 → +6 dB", (0.0016, 20)),
             (10, "10 → +20 dB", (1.3, 27))]
    for rv, rot, (xt, yt) in alvos:
        d = 20 * np.log10(rv)
        ax.plot(rv, d, "o", color=LARANJA, ms=4, zorder=5)
        ax.annotate(rot, xy=(rv, d), xytext=(xt, yt), textcoords="data", fontsize=7.6,
                    va="center", arrowprops=dict(arrowstyle="-", color="#999999", lw=0.6,
                                                 shrinkA=1, shrinkB=2))
    ax.set_ylim(-62, 32)
    ax.set_xlabel(r"razão de amplitudes $r=V_{saída}/V_{entrada}$")
    ax.set_ylabel(r"$G_{dB}$")
    ax.set_title(r"$G_{dB}=20\log_{10}(r)$")
    ax.xaxis.set_major_formatter(virgula())
    fig.tight_layout(w_pad=1.5)
    fig.savefig("fig_db.pdf")
    plt.close(fig)


# ================================================================ 7. FFT (Exercício 1)
def fig_fft():
    dur = 2.0
    t = np.arange(0, dur, 1 / FS)
    comps = [(200, 1.0), (440, 0.7), (1500, 0.6), (3000, 0.5)]
    x = sum(a * np.sin(2 * np.pi * f * t) for f, a in comps)
    y = lfilter(B, A, x)
    N = len(t)
    fr = np.fft.rfftfreq(N, 1 / FS)
    X = 2 * np.abs(np.fft.rfft(x)) / N
    Y = 2 * np.abs(np.fft.rfft(y)) / N

    fig, axs = plt.subplots(2, 1, figsize=(W, 4.2), gridspec_kw={"height_ratios": [1, 1.25]})
    ax = axs[0]
    i0 = int(0.5 * FS)
    seg = slice(i0, i0 + int(0.012 * FS))
    ax.plot((t[seg] - t[i0]) * 1000, x[seg], color=AZUL, lw=1.1, label="original $x[k]$")
    ax.plot((t[seg] - t[i0]) * 1000, y[seg], color=LARANJA, lw=1.5, label="filtrado $y[k]$")
    ax.set_xlabel("tempo (ms)")
    ax.set_ylabel("amplitude")
    ax.set_title("Domínio do tempo: o filtrado é a versão “alisada” do original")
    ax.set_ylim(-3, 3.9)
    ax.legend(frameon=False, ncol=2, loc="upper right")
    ax.xaxis.set_major_formatter(virgula())

    ax = axs[1]
    ax.plot(fr, X, color=AZUL, lw=1.0, label="FFT do original")
    ax.plot(fr, Y, color=LARANJA, lw=1.4, label="FFT do filtrado")
    ax.axvline(500, color=CINZA, ls="--", lw=0.9)
    ax.text(530, 1.22, "corte (500 Hz)", fontsize=7.8, color=CINZA, va="top")
    for f, a in comps:
        gy = abs(freqz(B, A, worN=[f], fs=FS)[1][0]) * a
        ax.annotate(f"{f} Hz\n{a:g} → {gy:.2f}".replace(".", ","), xy=(f, max(gy, a)),
                    xytext=(0, 4), textcoords="offset points", ha="center", fontsize=7.4)
    ax.set_xlim(0, 3500)
    ax.set_ylim(0, 1.25)
    ax.set_xlabel("frequência (Hz)")
    ax.set_ylabel("amplitude")
    ax.set_title("Domínio da frequência: os picos não mudam de lugar, só de altura")
    ax.legend(frameon=False, loc="upper right")
    ax.yaxis.set_major_formatter(virgula())
    fig.tight_layout(h_pad=1.2)
    fig.savefig("fig_fft.pdf")
    plt.close(fig)


# ================================================================ 8. fator Q
def fig_q():
    f = np.logspace(np.log10(200), np.log10(20000), 4000)
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.8), sharey=True)
    cores = ["#9ecae1", "#6baed6", "#3182bd", "#08519c", "#08306b"]
    ax = axs[0]
    for Q, c in zip([2, 5, 10, 20, 50], cores):
        b, a = iirpeak(2000, Q, fs=FS)
        ax.plot(f, ganho_db(b, a, f), color=c, lw=1.4, label=f"Q = {Q}")
    ax.axhline(-3, color=CINZA, ls=":", lw=0.8)
    ax.set_title("Passa-faixa em 2 kHz")
    ax.set_ylabel("ganho (dB)")
    ax.legend(frameon=False, fontsize=7.5, loc="lower left")
    ax = axs[1]
    for Q, c in zip([1, 5, 15, 30], cores[1:]):
        b, a = iirnotch(2000, Q, fs=FS)
        ax.plot(f, ganho_db(b, a, f), color=c, lw=1.4, label=f"Q = {Q}")
    ax.axhline(-3, color=CINZA, ls=":", lw=0.8)
    ax.set_title("Notch em 2 kHz")
    ax.legend(frameon=False, fontsize=7.5, loc="lower left")
    for ax in axs:
        eixo_hz(ax, 200, 20000)
        ax.set_ylim(-40, 3)
        ax.axvline(2000, color=LARANJA, ls="--", lw=0.8)
        ax.set_xlabel("frequência (Hz)")
    fig.tight_layout(w_pad=1.0)
    fig.savefig("fig_q.pdf")
    plt.close(fig)


if __name__ == "__main__":
    fig_tipos()
    fig_senoides()
    fig_media_movel()
    fig_bode()
    fig_polos()
    fig_db()
    fig_fft()
    fig_q()
    print("ok")
